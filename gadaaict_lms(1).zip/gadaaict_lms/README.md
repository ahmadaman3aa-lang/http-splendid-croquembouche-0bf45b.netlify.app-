# GadaaICT Class Tutorial - Full Stack LMS

Online tutorial platform for Ethiopian students (KG - Grade 12).
Languages: Afaan Oromoo | English | Amharic. Payments: Telebirr.

## Structure
- `database/schema.sql`      -> Complete PostgreSQL database schema
- `backend/`                 -> Django + Django REST Framework API
- `frontend/`                -> Trilingual UI prototype (works standalone in demo mode, connects to API when configured)

## Quick Start (Backend)
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser   # creates the ADMIN account
python manage.py runserver
```

## Quick Start (Frontend Demo)
Open `frontend/index.html` in a browser. Demo mode uses localStorage.
Set `API_URL` in `frontend/assets/js/api.js` to `http://127.0.0.1:8000/api` to connect the real backend.

## Payment Flow
1. Student registers -> status = PENDING
2. Student pays via Telebirr to 0912251318 and submits the transaction ID / screenshot
3. Admin verifies in Admin Panel -> approves -> student account becomes ACTIVE
4. (Phase 4) Replace manual step with Telebirr SDP Merchant API webhook for auto-activation

## Default Roles
- Admin:    created via createsuperuser
- Teacher:  created by Admin (role=teacher)
- Student:  self-registers, activated after payment approval
