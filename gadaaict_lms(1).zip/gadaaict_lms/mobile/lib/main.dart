import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'services/api_service.dart';
import 'services/locale_provider.dart';

void main() => runApp(const GadaaICTApp());

class GadaaICTApp extends StatelessWidget {
  const GadaaICTApp({super.key});

  @override
  Widget build(BuildContext context) => MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => LocaleProvider()),
          Provider(create: (_) => ApiService('https://yourdomain.com/api')),
        ],
        child: Consumer<LocaleProvider>(
          builder: (ctx, lp, _) => MaterialApp(
            title: 'GadaaICT',
            debugShowCheckedModeBanner: false,
            locale: lp.locale,
            supportedLocales: const [
              Locale('en'), Locale('am'), Locale('om'),
            ],
            home: ApiService.token == null
                ? const LoginScreen()
                : const HomeScreen(),
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF078930),
                  primary: const Color(0xFF078930)),
              useMaterial3: true,
            ),
          ),
        ),
      );
}
