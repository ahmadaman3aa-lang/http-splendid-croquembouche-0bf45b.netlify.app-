class User {
  final int id; final String name, email, role, status, lang;
  final String? gradeName;
  User.fromJson(Map j)
      : id = j['id'], name = j['first_name'] ?? j['email'], email = j['email'],
        role = j['role'], status = j['status'], lang = j['language'] ?? 'en',
        gradeName = j['grade_name'];
}

class Material {
  final int id; final String title, type, subjectName;
  final String? fileUrl, linkUrl;
  Material.fromJson(Map j)
      : id = j['id'], title = j['title'], type = j['type'],
        subjectName = j['subject_name'] ?? '',
        fileUrl = j['file_url'], linkUrl = j['link_url'];
}

class LiveClass {
  final int id; final String title, time, status, meetingUrl, subjectName;
  LiveClass.fromJson(Map j)
      : id = j['id'], title = j['title'], time = j['scheduled_at'] ?? '',
        status = j['status'], meetingUrl = j['meeting_url'],
        subjectName = j['subject_name'] ?? '';
}

class Enrollment {
  final int id; final String subjectName; final int progress;
  Enrollment.fromJson(Map j)
      : id = j['id'], subjectName = j['subject_name'] ?? '', progress = j['progress'] ?? 0;
}
