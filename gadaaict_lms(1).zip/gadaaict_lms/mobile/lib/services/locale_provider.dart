import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Trilingual switcher: EN / አማ / OM
class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('en');
  Locale get locale => _locale;

  static const labels = {'en': 'EN', 'am': 'አማ', 'om': 'OM'};

  LocaleProvider() { _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final code = p.getString('lang') ?? 'en';
    _locale = Locale(code);
    notifyListeners();
  }

  Future<void> setLocale(String code) async {
    _locale = Locale(code);
    final p = await SharedPreferences.getInstance();
    await p.setString('lang', code);
    notifyListeners();
  }
}
