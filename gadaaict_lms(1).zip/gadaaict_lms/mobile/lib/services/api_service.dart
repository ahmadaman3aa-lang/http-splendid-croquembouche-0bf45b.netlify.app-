import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  final String baseUrl;
  static String? token;

  ApiService(this.baseUrl);

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('token');
  }

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<Map<String, dynamic>> login(String email, String password) async {
    final r = await http.post(Uri.parse('$baseUrl/auth/login/'),
        headers: _headers, body: jsonEncode({'email': email, 'password': password}));
    final data = jsonDecode(r.body);
    if (r.statusCode == 200) {
      token = data['access'];
      final p = await SharedPreferences.getInstance();
      await p.setString('token', token!);
    }
    return {'status': r.statusCode, ...data};
  }

  Future<List<dynamic>> get(String path) async {
    final r = await http.get(Uri.parse('$baseUrl$path'), headers: _headers);
    if (r.statusCode != 200) throw Exception('GET $path -> ${r.statusCode}');
    return jsonDecode(r.body) is List ? jsonDecode(r.body) : jsonDecode(r.body)['results'] ?? [];
  }

  Future<Map<String, dynamic>> post(String path, Map body) async {
    final r = await http.post(Uri.parse('$baseUrl$path'),
        headers: _headers, body: jsonEncode(body));
    return {'status': r.statusCode, 'body': jsonDecode(r.body)};
  }

  static Future<void> logout() async {
    token = null;
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
  }
}
