import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import 'home_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final pass = TextEditingController();
  String? error;
  bool busy = false;

  Future<void> _login() async {
    setState(() { busy = true; error = null; });
    final api = context.read<ApiService>();
    try {
      final r = await api.login(email.text.trim(), pass.text);
      if (r['status'] == 200 && mounted) {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const HomeScreen()));
      } else {
        setState(() => error = r['detail'] ?? 'Login failed');
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext ctx) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(children: [
              Container(
                width: 84, height: 84,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Color(0xFF078930), Color(0xFFF9B40F)]),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Center(child: Text('ገ',
                    style: TextStyle(fontSize: 40, color: Colors.white,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(height: 16),
              const Text('GadaaICT Class Tutorial',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold,
                      color: Color(0xFF046A24))),
              const SizedBox(height: 28),
              TextField(controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                      labelText: 'Email', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: pass, obscureText: true,
                  decoration: const InputDecoration(
                      labelText: 'Password', border: OutlineInputBorder())),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: busy ? null : _login,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: busy
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2,
                                color: Colors.white))
                        : const Text('Login', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.push(ctx,
                    MaterialPageRoute(builder: (_) => const RegisterScreen())),
                child: const Text("New student? Register"),
              ),
            ]),
          ),
        ),
      );
}
