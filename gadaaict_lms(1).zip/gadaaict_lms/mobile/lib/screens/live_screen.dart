import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_service.dart';
import '../models/models.dart' as m;

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});
  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  List<m.LiveClass> classes = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final data = await context.read<ApiService>().get('/content/live-classes/');
      setState(() => classes = data.map((j) => m.LiveClass.fromJson(j)).toList());
    } catch (_) {}
  }

  @override
  Widget build(BuildContext ctx) => RefreshIndicator(
        onRefresh: _load,
        child: classes.isEmpty
            ? const Center(child: Text('No live classes scheduled'))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: classes.length,
                itemBuilder: (ctx, i) {
                  final c = classes[i];
                  final live = c.status == 'live';
                  return Card(
                    child: ListTile(
                      leading: Icon(Icons.circle,
                          size: 14,
                          color: live ? Colors.red : Colors.grey),
                      title: Text(c.title,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${c.subjectName} · ${c.time}'),
                      trailing: FilledButton(
                        style: FilledButton.styleFrom(
                            backgroundColor: live ? Colors.red
                                : const Color(0xFF078930)),
                        onPressed: () => launchUrl(Uri.parse(c.meetingUrl),
                            mode: LaunchMode.externalApplication),
                        child: Text(live ? 'JOIN NOW' : 'Join'),
                      ),
                    ),
                  );
                }),
      );
}
