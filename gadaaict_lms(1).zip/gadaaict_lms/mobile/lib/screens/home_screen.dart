import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/locale_provider.dart';
import '../models/models.dart' as m;
import 'login_screen.dart';
import 'materials_screen.dart';
import 'live_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  List<m.Enrollment> subjects = [];
  Map<String, dynamic>? me;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<ApiService>();
    try {
      final enrolls = await api.get('/academics/enrollments/');
      me = (await api.post('/auth/me/', {}))['body'];
      setState(() => subjects = enrolls.map((j) => m.Enrollment.fromJson(j)).toList());
    } catch (_) {}
  }

  @override
  Widget build(BuildContext ctx) {
    final lp = context.watch<LocaleProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('GadaaICT'),
        actions: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'om', label: Text('OM')),
              ButtonSegment(value: 'am', label: Text('አማ')),
              ButtonSegment(value: 'en', label: Text('EN')),
            ],
            selected: {lp.locale.languageCode},
            onSelectionChanged: (s) => lp.setLocale(s.first),
            showSelectedIcon: false,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await ApiService.logout();
              if (ctx.mounted) {
                Navigator.pushReplacement(ctx,
                    MaterialPageRoute(builder: (_) => const LoginScreen()));
              }
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: [const MaterialsScreen(), const LiveScreen(), _subjectsTab()][tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'Materials'),
          NavigationDestination(icon: Icon(Icons.videocam), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.school), label: 'My Subjects'),
        ],
      ),
    );
  }

  Widget _subjectsTab() => subjects.isEmpty
      ? const Center(child: Text('No enrollments yet'))
      : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: subjects.length,
          itemBuilder: (ctx, i) {
            final s = subjects[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.book)),
                title: Text(s.subjectName,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                        value: s.progress / 100,
                        backgroundColor: Colors.grey[300],
                        color: const Color(0xFF078930)),
                    const SizedBox(height: 4),
                    Text('${s.progress}%'),
                  ],
                ),
              ),
            );
          },
        );
}
