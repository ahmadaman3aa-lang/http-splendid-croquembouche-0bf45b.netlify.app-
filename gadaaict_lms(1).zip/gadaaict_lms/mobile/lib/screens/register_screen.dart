import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';

/// 3-step registration: account -> Telebirr payment -> done.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  int step = 0;
  final name = TextEditingController(), email = TextEditingController(),
       phone = TextEditingController(), pass = TextEditingController(),
       txn = TextEditingController();
  int? gradeId;

  static const grades = ['KG', 'G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8', 'G9', 'G10', 'G11', 'G12'];
  static const fees = [150,150,150,150,200,200,200,250,250,300,300,350,350];

  Future<void> _submitAccount() async {
    final r = await context.read<ApiService>().post('/auth/register/', {
      'email': email.text, 'username': email.text.split('@')[0],
      'full_name': name.text, 'password': pass.text,
      'phone': phone.text, 'grade_id': gradeId, 'language': 'en',
    });
    if (r['status'] == 201 || r['status'] == 200) {
      setState(() => step = 1);
    }
  }

  Future<void> _submitPayment() async {
    final r = await context.read<ApiService>().post('/payments/', {
      'amount': fees[gradeId ?? 0], 'months_paid': 1,
      'telebirr_txn': txn.text,
    });
    if (r['status'] == 201 || r['status'] == 200) setState(() => step = 2);
  }

  @override
  Widget build(BuildContext ctx) => Scaffold(
        appBar: AppBar(title: const Text('Register')),
        body: Stepper(
          currentStep: step,
          controlsBuilder: (_, __) => const SizedBox.shrink(),
          steps: [
            Step(
              title: const Text('Account'), isActive: step == 0, state: step > 0 ? StepState.complete : StepState.indexed,
              content: Column(children: [
                TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name')),
                TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
                TextField(controller: phone, decoration: const InputDecoration(labelText: 'Phone (Telebirr)')),
                DropdownButtonFormField<int>(
                  value: gradeId,
                  decoration: const InputDecoration(labelText: 'Grade'),
                  items: [for (var i = 0; i < grades.length; i++)
                    DropdownMenuItem(value: i + 1, child: Text('${grades[i]} — ${fees[i]} ETB/month'))],
                  onChanged: (v) => setState(() => gradeId = v),
                ),
                TextField(controller: pass, obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password')),
                const SizedBox(height: 16),
                FilledButton(onPressed: _submitAccount, child: const Text('Next')),
              ]),
            ),
            Step(
              title: const Text('Telebirr Payment'), isActive: step == 1,
              content: Column(children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [Color(0xFF4E1E79), Color(0xFF7B2CBF)]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Column(children: [
                    Text('💜 Telebirr', style: TextStyle(color: Colors.white70)),
                    Text('0912 251 318',
                        style: TextStyle(color: Colors.white, fontSize: 28,
                            fontWeight: FontWeight.bold, letterSpacing: 2)),
                    Text('Send the monthly fee, then enter the transaction ID',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70)),
                  ]),
                ),
                const SizedBox(height: 16),
                TextField(controller: txn,
                    decoration: const InputDecoration(
                        labelText: 'Transaction ID', border: OutlineInputBorder())),
                const SizedBox(height: 16),
                FilledButton(onPressed: _submitPayment, child: const Text('Submit Payment')),
              ]),
            ),
            Step(
              title: const Text('Done'), isActive: step == 2,
              content: const Column(children: [
                Icon(Icons.celebration, size: 64, color: Color(0xFF078930)),
                SizedBox(height: 10),
                Text('Application submitted!',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('Your account is pending admin approval after payment verification.'),
              ]),
            ),
          ],
        ),
      );
}
