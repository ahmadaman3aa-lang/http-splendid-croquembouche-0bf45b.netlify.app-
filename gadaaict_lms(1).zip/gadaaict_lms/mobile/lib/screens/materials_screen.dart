import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_service.dart';
import '../models/models.dart' as m;

class MaterialsScreen extends StatefulWidget {
  const MaterialsScreen({super.key});
  @override
  State<MaterialsScreen> createState() => _MaterialsScreenState();
}

class _MaterialsScreenState extends State<MaterialsScreen> {
  List<m.Material> items = [];
  String type = '';

  static const icons = {'pdf': Icons.picture_as_pdf, 'video': Icons.play_circle,
    'audio': Icons.audiotrack, 'ppt': Icons.slideshow, 'link': Icons.link, 'note': Icons.notes};

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final data = await context.read<ApiService>()
          .get('/content/materials/${type.isEmpty ? '' : '?type=$type'}');
      setState(() => items = data.map((j) => m.Material.fromJson(j)).toList());
    } catch (_) {}
  }

  Future<void> _open(m.Material mat) async {
    final url = mat.linkUrl ?? mat.fileUrl;
    if (url != null && url != '#') {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext ctx) => Column(children: [
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 8), children: [
            for (final f in ['', 'video', 'pdf', 'audio', 'ppt', 'link'])
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilterChip(
                  label: Text(f.isEmpty ? 'All' : f.toUpperCase()),
                  selected: type == f,
                  onSelected: (_) { setState(() => type = f); _load(); },
                ),
              ),
          ]),
        ),
        Expanded(
          child: items.isEmpty
              ? const Center(child: Text('No materials yet'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  itemBuilder: (ctx, i) {
                    final mat = items[i];
                    return Card(
                      child: ListTile(
                        leading: Icon(icons[mat.type] ?? Icons.insert_drive_file,
                            color: const Color(0xFF078930)),
                        title: Text(mat.title,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text('${mat.subjectName} · ${mat.type.toUpperCase()}'),
                        trailing: const Icon(Icons.open_in_new),
                        onTap: () => _open(mat),
                      ),
                    );
                  }),
        ),
      ]);
}
