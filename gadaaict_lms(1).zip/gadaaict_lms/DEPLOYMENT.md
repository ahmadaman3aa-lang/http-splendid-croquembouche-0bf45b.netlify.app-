# GadaaICT LMS — Deployment Guide

## 1. Local development
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # fill in your values
python manage.py makemigrations accounts academics payments content assessment comms
python manage.py migrate
python manage.py seed          # creates KG-Grade 12 + subjects (EN/AM/OM) + fees
python manage.py createsuperuser
python manage.py runserver
```

## 2. Connect the frontend
Edit `frontend/assets/js/app.js`:
```js
const API_URL = 'http://127.0.0.1:8000/api';
```
Serve `frontend/` with any static server (or deploy to Netlify/Vercel).

## 3. Production (Ubuntu + Nginx + Gunicorn)
```bash
sudo apt install nginx postgresql python3-pip
pip install gunicorn pycryptodome
gunicorn --workers 3 gadaaict.wsgi:application --bind 127.0.0.1:8000
```
Nginx: proxy `/api/` + `/admin/` + `/media/` to Gunicorn; serve `frontend/` as static.

## 4. Telebirr go-live checklist
1. Register as merchant at Ethio Telecom SDP
2. Fill TB_* values in `.env`, switch `TB_BASE_URL` to production URL
3. Expose `https://yourdomain.com/api/payments/telebirr/webhook/` (HTTPS required)
4. Test with small amounts before enabling auto-activation

## 5. SMS gateway
Pick a gateway with Ethiopia coverage (Eskalate, Infobip, etc.), set
SMS_API_KEY / SMS_SENDER / SMS_API_URL in `.env`.

## 6. Backups
Nightly `pg_dump gadaaict` + rsync of `backend/media/` (payment screenshots, materials).
