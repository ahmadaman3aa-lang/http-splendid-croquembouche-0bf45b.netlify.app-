-- =============================================================
-- GadaaICT LMS - Complete Database Schema (PostgreSQL)
-- Ethiopian online tutorial platform: KG - Grade 12
-- =============================================================

CREATE TABLE grades (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(20) NOT NULL UNIQUE,          -- KG, Grade 1 ... Grade 12
    level_order INT NOT NULL,                        -- 0=KG, 1..12
    monthly_fee NUMERIC(10,2) NOT NULL DEFAULT 0,    -- Telebirr fee per month
    created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE subjects (
    id       SERIAL PRIMARY KEY,
    grade_id INT NOT NULL REFERENCES grades(id) ON DELETE CASCADE,
    name_en  VARCHAR(120) NOT NULL,
    name_am  VARCHAR(120) NOT NULL,
    name_om  VARCHAR(120) NOT NULL,
    UNIQUE(grade_id, name_en)
);

-- Extended user profile (Django auth_user holds username/password/email)
CREATE TABLE profiles (
    id            SERIAL PRIMARY KEY,
    user_id       INT NOT NULL UNIQUE REFERENCES auth_user(id) ON DELETE CASCADE,
    role          VARCHAR(20) NOT NULL DEFAULT 'student'
                  CHECK (role IN ('student','teacher','admin','parent')),
    phone         VARCHAR(20) NOT NULL UNIQUE,          -- Telebirr number
    language      VARCHAR(5)  NOT NULL DEFAULT 'en'
                  CHECK (language IN ('en','am','om')),
    status        VARCHAR(20) NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','active','suspended')),
    grade_id      INT REFERENCES grades(id),            -- student grade
    parent_phone  VARCHAR(20),                          -- optional parent contact
    approved_by_id INT REFERENCES auth_user(id),
    approved_at   TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_profiles_status ON profiles(status);
CREATE INDEX idx_profiles_role   ON profiles(role);

CREATE TABLE enrollments (
    id         SERIAL PRIMARY KEY,
    student_id INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    subject_id INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    status     VARCHAR(20) NOT NULL DEFAULT 'active'
               CHECK (status IN ('active','completed','dropped')),
    progress   INT NOT NULL DEFAULT 0,                  -- 0-100%
    enrolled_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(student_id, subject_id)
);

CREATE TABLE payments (
    id             SERIAL PRIMARY KEY,
    student_id     INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    amount         NUMERIC(10,2) NOT NULL,
    months_paid    INT NOT NULL DEFAULT 1,
    telebirr_txn   VARCHAR(60) NOT NULL,                -- transaction id from Telebirr
    screenshot     VARCHAR(255),                        -- uploaded proof image path
    status         VARCHAR(20) NOT NULL DEFAULT 'submitted'
                   CHECK (status IN ('submitted','verified','rejected')),
    reviewed_by_id INT REFERENCES auth_user(id),
    reviewed_at    TIMESTAMPTZ,
    note           TEXT,
    created_at     TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_payments_status ON payments(status);

CREATE TABLE materials (
    id         SERIAL PRIMARY KEY,
    subject_id INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id INT NOT NULL REFERENCES profiles(id),
    title      VARCHAR(200) NOT NULL,
    type       VARCHAR(10) NOT NULL
               CHECK (type IN ('pdf','video','audio','ppt','link','note')),
    file_url   VARCHAR(500),                            -- local/S3 path
    link_url   VARCHAR(500),                            -- youtube/drive link
    language   VARCHAR(5) DEFAULT 'en',
    is_live    BOOLEAN DEFAULT FALSE,                   -- pinned to top
    created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_materials_subject ON materials(subject_id, type);

CREATE TABLE live_classes (
    id          SERIAL PRIMARY KEY,
    subject_id  INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id  INT NOT NULL REFERENCES profiles(id),
    title       VARCHAR(200) NOT NULL,
    description TEXT,
    meeting_url VARCHAR(500) NOT NULL,                  -- Jitsi/Zoom/Meet link
    scheduled_at TIMESTAMPTZ NOT NULL,
    duration_min INT NOT NULL DEFAULT 60,
    status      VARCHAR(15) NOT NULL DEFAULT 'scheduled'
                CHECK (status IN ('scheduled','live','done','cancelled')),
    created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE class_sessions (
    id         SERIAL PRIMARY KEY,
    live_class_id INT REFERENCES live_classes(id) ON DELETE SET NULL,
    subject_id INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id INT NOT NULL REFERENCES profiles(id),
    topic      VARCHAR(200),
    held_at    TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE attendance (
    id         SERIAL PRIMARY KEY,
    session_id INT NOT NULL REFERENCES class_sessions(id) ON DELETE CASCADE,
    student_id INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    status     VARCHAR(10) NOT NULL CHECK (status IN ('present','absent','late','excused')),
    UNIQUE(session_id, student_id)
);
CREATE INDEX idx_attendance_student ON attendance(student_id, status);

CREATE TABLE assignments (
    id          SERIAL PRIMARY KEY,
    subject_id  INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id  INT NOT NULL REFERENCES profiles(id),
    title       VARCHAR(200) NOT NULL,
    description TEXT,
    max_score   NUMERIC(6,2) NOT NULL DEFAULT 100,
    file_url    VARCHAR(500),
    due_at      TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE submissions (
    id            SERIAL PRIMARY KEY,
    assignment_id INT NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
    student_id    INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    file_url      VARCHAR(500),
    text_answer   TEXT,
    submitted_at  TIMESTAMPTZ DEFAULT now(),
    UNIQUE(assignment_id, student_id)
);

CREATE TABLE marks (
    id            SERIAL PRIMARY KEY,
    submission_id INT NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
    score         NUMERIC(6,2) NOT NULL,
    feedback      TEXT,
    marked_by_id  INT NOT NULL REFERENCES profiles(id),
    marked_at     TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE quizzes (
    id         SERIAL PRIMARY KEY,
    subject_id INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id INT NOT NULL REFERENCES profiles(id),
    title      VARCHAR(200) NOT NULL,
    total_marks NUMERIC(6,2) NOT NULL DEFAULT 20,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE questions (
    id       SERIAL PRIMARY KEY,
    quiz_id  INT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    text     TEXT NOT NULL,
    options  JSONB NOT NULL,        -- ["A","B","C","D"]
    answer   VARCHAR(300) NOT NULL,
    marks    NUMERIC(5,2) NOT NULL DEFAULT 1
);

CREATE TABLE quiz_attempts (
    id         SERIAL PRIMARY KEY,
    quiz_id    INT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    student_id INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    answers    JSONB NOT NULL,      -- {question_id: chosen}
    score      NUMERIC(6,2),
    taken_at   TIMESTAMPTZ DEFAULT now(),
    UNIQUE(quiz_id, student_id)
);

CREATE TABLE announcements (
    id        SERIAL PRIMARY KEY,
    author_id INT NOT NULL REFERENCES profiles(id),
    title     VARCHAR(200) NOT NULL,
    body      TEXT NOT NULL,
    audience  VARCHAR(15) NOT NULL DEFAULT 'all'
              CHECK (audience IN ('all','students','teachers','grade')),
    grade_id  INT REFERENCES grades(id),   -- when audience = grade
    language  VARCHAR(5) DEFAULT 'en',
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE certificates (
    id         SERIAL PRIMARY KEY,
    student_id INT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    subject_id INT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    serial_no  VARCHAR(40) NOT NULL UNIQUE,
    issued_at  TIMESTAMPTZ DEFAULT now()
);
