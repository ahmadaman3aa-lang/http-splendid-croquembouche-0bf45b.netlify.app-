/* =========================================================
   GadaaICT LMS - shared engine
   - Trilingual UI (Afaan Oromoo / English / Amharic)
   - Demo mode: localStorage data store (works with file://)
   - Live mode: set API_URL to your Django backend
   ========================================================= */
const API_URL = ''; // e.g. 'http://127.0.0.1:8000/api' — empty = demo mode

/* ---------------- I18N ---------------- */
const I18N = {
en: {
  home:'Home', courses:'Courses', pricing:'Pricing', about:'About', login:'Login', register:'Register',
  logout:'Logout', hero_t:'Quality Education for Every Ethiopian Child — KG to Grade 12',
  hero_p:'Learn in Afaan Oromoo, Amharic and English. Video lessons, PDF books, live classes and exams — all on your phone.',
  cta_start:'Start Learning', cta_how:'How it works', grades:'Our Classes', grades_s:'From Kindergarten to Grade 12 — every subject, every level.',
  feat:'Everything a Student Needs', feat_s:'One platform for lessons, exams and live classes.',
  f1:'Video Lessons', f1d:'Watch recorded lessons anytime, organized by grade and subject.',
  f2:'PDF Books & Notes', f2d:'Download Ministry textbooks, lecture notes and PowerPoints.',
  f3:'Live Classes', f3d:'Join live classes with real teachers via video meeting.',
  f4:'Quizzes & Exams', f4d:'Take auto-graded quizzes and teacher-marked assignments.',
  f5:'Attendance Tracking', f5d:'Teachers mark attendance; parents can follow progress.',
  f6:'3 Languages', f6d:'Full interface and content support for Afaan Oromoo, Amharic, English.',
  how:'How It Works', how_s:'Simple steps to join GadaaICT.',
  s1:'Register', s1d:'Create your account with your name, grade and phone number.',
  s2:'Pay with Telebirr', s2d:'Send the monthly fee to 0912 251 318 using Telebirr and submit your transaction ID.',
  s3:'Get Approved', s3d:'Admin verifies your payment and activates your account.',
  s4:'Start Learning', s4d:'Watch videos, join live classes, take quizzes and track your progress.',
  price:'Affordable Pricing', price_s:'One simple monthly fee per grade level.',
  per_month:'/month', pay_to:'Pay via Telebirr', pay_note:'After payment, keep your transaction ID — you will need it to activate your account.',
  register_t:'Create Student Account', full_name:'Full Name', email:'Email', phone:'Phone (Telebirr)', grade:'Select Grade',
  language:'Preferred Language', parent_phone:'Parent Phone (optional)', password:'Password', next:'Next', back:'Back', submit:'Submit',
  step1:'Account', step2:'Payment', step3:'Done',
  pay_t:'Complete Your Payment', pay_d:'Send the fee to our Telebirr number, then enter the transaction details below.',
  amount:'Amount (ETB)', txn:'Telebirr Transaction ID', upload:'Upload payment screenshot (optional)',
  done_t:'Application Submitted!', done_d:'Your account is pending admin approval. You will receive an SMS once your payment is verified. Then log in and start learning.',
  go_login:'Go to Login', login_t:'Welcome Back', login_d:'Log in with your email and password.',
  dash:'Dashboard', my_subjects:'My Subjects', live:'Live Classes', materials:'Materials', attendance:'Attendance',
  progress:'Progress', announcements:'Announcements', certificates:'Certificates', upcoming:'Upcoming Live Classes',
  pending:'Pending Approvals', users:'Students', revenue:'Payments', stats:'Overview',
  upload_mat:'Upload Material', take_att:'Take Attendance', marking:'Marking / Evaluation', post_ann:'Post Announcement',
  live_now:'LIVE NOW', scheduled:'Scheduled', finished:'Finished',
  type:'Type', title:'Title', subject:'Subject', action:'Actions', approve:'Approve', reject:'Reject',
  status:'Status', date:'Date', score:'Score', name:'Name', present:'Present', absent:'Absent', late:'Late', excused:'Excused',
  save:'Save', download:'Download', join:'Join Class', watch:'Watch', open:'Open', no_data:'No data yet.',
  teacher_d:'Teacher Dashboard', student_d:'Student Dashboard', admin_d:'Admin Dashboard',
  welcome:'Welcome', verify_pay:'Verify Payment', fee:'Fee', students:'students',
  assign:'Assignments', quiz:'Quizzes', submit_work:'Submit Assignment', enrolled:'Enrolled',
  footer_t:'GadaaICT Class Tutorial', footer_p:'Empowering the next generation of Ethiopia through accessible, quality online education.',
  quick:'Quick Links', contact:'Contact', rights:'All rights reserved.',
  select_grade:'Choose your grade', months:'months', already:'Already have an account?', need_acc:"Don't have an account?",
  total:'Total', view:'View', mark:'Mark', feedback:'Feedback', gradebook:'Gradebook',
  pending_msg:'⏳ Your account is pending approval. Please complete payment to 0912 251 318 via Telebirr.',
  ann_ph:'Write announcement...', ann_t_ph:'Announcement title', all:'Everyone', active:'Active', suspended:'Suspended',
  sub_ok:'Submitted successfully!', mark_ok:'Attendance saved!', appr_ok:'Student approved & activated!'
},
am: {
  home:'መነሻ', courses:'ትምህርቶች', pricing:'ዋጋ', about:'ስለ እኛ', login:'መግቢያ', register:'መመዝገቢያ',
  logout:'ውጣ', hero_t:'ለእያንዳንዱ የኢትዮጵያ ተማሪ ጥራት ያለው ትምህርት — ከኪጂ እስከ 12ኛ ክፍል',
  hero_p:'በአፋን ኦሮሞ፣ በአማርኛ እና በእንግሊዝኛ ይማሩ። የቪዲዮ ትምህርቶች፣ የፒዲኤፍ መጽሐፍት፣ቀጥታ ክፍሎች እና ፈተናዎች — ሁሉም በስልክዎ ላይ።',
  cta_start:'አሁን ይጀምሩ', cta_how:'እንዴት እንደሚሰራ', grades:'ክፍሎቻችን', grades_s:'ከኪንደርጋርተን እስከ 12ኛ ክፍል — እያንዳንዱ ርዕሰ ጉዳይ እና ደረጃ።',
  feat:'ተማሪ የሚፈልገው ሁሉ', feat_s:'ለትምህርት፣ ለፈተና እና ለቀጥታ ክፍሎች አንድ መድረክ።',
  f1:'የቪዲዮ ትምህርቶች', f1d:'የቀረቡ ትምህርቶችን በማንኛውም ጊዜ ይመልከቱ።',
  f2:'የፒዲኤፍ መጽሐፍት እና ማስታወሻዎች', f2d:'የመንግሥት መጽሐፍትን፣ ማስታወሻዎችን እና ፕሬዘንቴሽኖችን ያውርዱ።',
  f3:'ቀጥታ ክፍሎች', f3d:'ከእውነተኛ አስተማሪዎች ጋር በቪዲዮ መገናኛ ይቀላቀሉ።',
  f4:'ፈተናዎች እና ግምገማዎች', f4d:'በአውቶማቲክ የሚገመገሙ ፈተናዎችን ይውሰዱ።',
  f5:'የአቴንዳንስ ክትትል', f5d:'አስተማሪዎች አቴንዳንስ ያስመዝግባሉ፤ ወላጆች ሂደትን ይከታተላሉ።',
  f6:'3 ቋንቋዎች', f6d:'ሙሉ ድጋፍ ለአፋን ኦሮሞ፣ አማርኛ እና እንግሊዝኛ።',
  how:'እንዴት እንደሚሰራ', how_s:'በቀላሉ እንዴት እንደምንቀላቀል።',
  s1:'ይመዝገቡ', s1d:'በስምዎ፣ በክፍልዎ እና በስልክ ቁጥርዎ አካውንት ይፍጠሩ።',
  s2:'በቴሌብር ክፍለዋጅ ይላኩ', s2d:'ወርሃዊ ክፍያውን ወደ 0912 251 318 በቴሌብር ላኩ እና የግብይቱን መለያ ያስገቡ።',
  s3:'ማጽደቅ', s3d:'አስተዳዳሪ ክፍያዎን ያረጋግጣል እና አካውንትዎን ያንቃል።',
  s4:'መማር ይጀምሩ', s4d:'ቪዲዮዎችን ይመልከቱ፣ ቀጥታ ክፍሎችን ይቀላቀሉ፣ ፈተና ይውሰዱ።',
  price:'ተመጣጣኝ ዋጋ', price_s:'በክፍል ደረጃ አንድ ቀላል ወርሃዊ ክፍያ።',
  per_month:'/ወር', pay_to:'በቴሌብር ይክፈሉ', pay_note:'ክፍያ ከፈፀሙ በኋላ የግብይቱን መለያ ያስታውሱ — አካውንትዎን ለማንቃት ያስፈልጋል።',
  register_t:'የተማሪ አካውንት ይፍጠሩ', full_name:'ሙሉ ስም', email:'ኢሜይል', phone:'ስልክ (ቴሌብር)', grade:'ክፍል ይምረጡ',
  language:'የሚመከር ቋንቋ', parent_phone:'ስልክ ወላጅ (አማራጭ)', password:'የይለፍ ቃል', next:'ቀጣይ', back:'ወደ ኋላ', submit:'አስገባ',
  step1:'አካውንት', step2:'ክፍያ', step3:'ተጠናቋል',
  pay_t:'ክፍያዎን ያጠናቅቁ', pay_d:'ክፍያውን ወደ ቴሌብር ቁጥራችን ላኩ፤ ከዚያ የግብይቱን ዝርዝር ያስገቡ።',
  amount:'መጠን (ብር)', txn:'የቴሌብር የግብይት መለያ', upload:'የክፍያ ማስረጃ ፎቶ ይጫኑ (አማራጭ)',
  done_t:'ማመልከቻዎ ተልኳል!', done_d:'አካውንትዎ የአስተዳዳሪ ማጽደቅ እየጠበቀ ነው። ክፍያዎ ሲረጋገጥ ኤስኤምኤስ ይልካል።',
  go_login:'ወደ መግቢያ ሂድ', login_t:'እንኳን ደህና መጡ', login_d:'በኢሜይል እና በይለፍ ቃል ይግቡ።',
  dash:'ዳሽቦርድ', my_subjects:'ትምህርቶቼ', live:'ቀጥታ ክፍሎች', materials:'መረጃዎች', attendance:'አቴንዳንስ',
  progress:'እድገት', announcements:'ማስታወቂያዎች', certificates:'ምስክር ወረቀቶች', upcoming:'ቀጣይ ቀጥታ ክፍሎች',
  pending:'በጠባቂያ ላይ ያሉ', users:'ተማሪዎች', revenue:'ክፍያዎች', stats:'አጠቃላይ እይታ',
  upload_mat:'መረጃ ስቀል', take_att:'አቴንዳንስ አስመዝግብ', marking:'ግምገማ / ማርክ', post_ann:'ማስታወቂያ ልጥፍ',
  live_now:'ቀጥታ ላይ', scheduled:'ታቅዷል', finished:'ተጠናቋል',
  type:'አይነት', title:'ርዕስ', subject:'ርዕሰ ጉዳይ', action:'እርምጃዎች', approve:'አጽድቅ', reject:'ከልክል',
  status:'ሁኔታ', date:'ቀን', score:'ነጥብ', name:'ስም', present:'አቅርቧል', absent:'አልቀረበም', late:'ዘግይቷል', excused:'የተፈቀደለት',
  save:'አስቀምጥ', download:'አውርድ', join:'ክፍሉን ስለቀላቀል', watch:'ተመልከት', open:'ክፈት', no_data:'ምንም መረጃ የለም።',
  teacher_d:'የአስተማሪ ዳሽቦርድ', student_d:'የተማሪ ዳሽቦርድ', admin_d:'የአስተዳዳሪ ዳሽቦርድ',
  welcome:'እንኳን ደህና መጡ', verify_pay:'ክፍያ አረጋግጥ', fee:'ክፍያ', students:'ተማሪዎች',
  assign:'ስራዎች', quiz:'ፈተናዎች', submit_work:'ስራ ስቀል', enrolled:'ተመዝግቧል',
  footer_t:'ጋዳአይሲቲ ክላስ ቱቶሪያል', footer_p:'በተደራሽ ጥራታማ የመስመር ላይ ትምህርት የሚቀጥለውን ትውልድ እናብቃለን።',
  quick:'ፈጣን ሊንኮች', contact:'አድራሻ', rights:'መብቱ በህግ የተጠበቀ ነው።',
  select_grade:'ክፍልዎን ይምረጡ', months:'ወር', already:'አካውንት አለዎት?', need_acc:'አካውንት የለዎትም?',
  total:'ጠቅላላ', view:'እይ', mark:'ነጥብ ስጥ', feedback:'አስተያየት', gradebook:'የነጥብ መጽሐፍ',
  pending_msg:'⏳ አካውንትዎ ማጽደቅ እየጠበቀ ነው። እባክዎ ወደ 0912 251 318 በቴሌብር ክፍያ ያጠናቅቁ።',
  ann_ph:'ማስታወቂያ ይጻፉ...', ann_t_ph:'ርዕስ ማስታወቂያ', all:'ሁሉም', active:'ንቁ', suspended:'ተሰናክሏል',
  sub_ok:'በተሳካ ሁኔታ ተልኳል!', mark_ok:'አቴንዳንስ ተቀምጧል!', appr_ok:'ተማሪ ጸድቆ ተንብቧል!'
},
om: {
  home:'Fuula Jalqabaa', courses:'Barumsa', pricing:'Gatii', about:'Waa\'ee Keenya', login:'Seeni', register:'Galmaa\'i',
  logout:'Ba\'i', hero_t:'Barumsi Qulqulluu Barattoota Itoophiyaa Hundaaf — KG hanga Kutaa 12',
  hero_p:'Afaan Oromoo, Amaaraa fi Afaan Ingiliziin baradha. Vidyoon barumsaa, kitaabota PDF, kutaalee toora interneetii fi qorannoo — hundi isaa bilbilakee keessatti.',
  cta_start:'Amma Jalqabi', cta_how:'Akkamitti Hojjeta', grades:'Kutaaleen Keenya', grades_s:'KG irraa hanga Kutaa 12 — barumsi hundi, sadarkaa hundi.',
  feat:'Wanta Barattoonni Hunduu Barbaadan', feat_s:'Wabii tokko barumsaaf, qorannaaf akkasumas kutaalee toora interneetii.',
  f1:'Vidyoon Barumsaa', f1d:'Barumsa ragaa\'e yeroo kamiyyuu daawwadhaa.',
  f2:'Kitaabota PDF fi Yaadannoo', f2d:'Kitaabota mootummaa, yaadannoo fi PowerPoint asumaan buufadhaa.',
  f3:'Kutaalee Toora Interneetii', f3d:'Barsiisota dhugaa waliin kutaalee toora interneetii keessatti makamaa.',
  f4:'Qorannoolee', f4d:'Qorannoowwan ofumaan qajeelaman fudhadhaa.',
  f5:'Hordoffii Argamaa', f5d:'Barsiisonni argamaa galmeessu; maatinnis hordofa.',
  f6:'Afaanota 3', f6d:'Afaan Oromoo, Amaaraa fi Ingilizii deggersa guutuu qabu.',
  how:'Akkamitti Hojjeta', how_s:'Tarkaanfiiwwan salphaa makiina seenuf.',
  s1:'Galmaa\'aa', s1d:'Maqaa, kutaa fi lakkoofsa bilbilakee fayyadamuun akkaawuntii uumi.',
  s2:'Telebirr\'iin Kaffali', s2d:'Kaffaltii ji\'aa 0912 251 318 seena, lakkoofsa tarkaanfichaa galchi.',
  s3:'Mirkanaa\'uu', s3d:'Adeemsaan kaffaltii kee mirkaneessee akkaawuntii kee banfatte kenna.',
  s4:'Barachuu Jalqabi', s4d:'Viidiyoo daawwadhu, kutaalee seeni, qorannoo fudhadhu.',
  price:'Gatii Rakkoo Malee', price_s:'Kaffaltii ji\'aa tokko sadarkaa kutaa tokkoo.',
  per_month:'/ji\'a', pay_to:'Telebirr\'iin Kaffali', pay_note:'Kaffaltii booda lakkoofsa tarkaanfichaa eegi — akkaawuntii kee banachuuf ni barbaachisa.',
  register_t:'Akaawuntii Barataa Uumi', full_name:'Maqaa Guutuu', email:'Imeelii', phone:'Bilbila (Telebirr)', grade:'Kutaa Filadhu',
  language:'Afaan Filatamuu', parent_phone:'Bilbila Maatii (filannoo)', password:'Jecha Darbii', next:'Itti Aane', back:'Duubatti', submit:'Galchi',
  step1:'Akaawuntii', step2:'Kaffaltii', step3:'Xumurame',
  pay_t:'Kaffaltii Kee Xumuri', pay_d:'Kaffaltii lakkoofsa Telebirr keenyaatti ergi, booda odeeffannoo tarkaanfichaa galchi.',
  amount:'Hamma (ETB)', txn:'Lakkoofsa Tarkaanfii Telebirr', upload:'Ragaa kaffaltii fe\'i (filannoo)',
  done_t:'Iyyannoo Kee Ergameera!', done_d:'Akaawuntii kee mirkaneeffannaa adeemsa eeggachaa jira. Kaffaltiin kee mirkanaa\'ee booda SMS siif ergama. Boodas seeni barachuu jalqabi.',
  go_login:'Seenitti Deebi\'i', login_t:'Baga Nagaan Dhuftan', login_d:'Imeelii fi jecha darbii fayyadamuun seeni.',
  dash:'Daashboordii', my_subjects:'Barumsa Koo', live:'Kutaalee Toora Interneetii', materials:'Qabiyyee', attendance:'Argamaa',
  progress:'Ariifachiisa', announcements:'Beeksisa', certificates:'Ragaa Galmee', upcoming:'Kutaalee Toora Interneetii Dhufan',
  pending:'Eeggatoota', users:'Barattoota', revenue:'Kaffaltiiwwan', stats:'Cuunfaa Waliigalaa',
  upload_mat:'Qabiyyee Olkaa\'i', take_att:'Argamaa Galmeessi', marking:'Qorannoo / Makiina', post_ann:'Beeksisa Maxxansi',
  live_now:'AMMA TOORA INTERNETII', scheduled:'Karaa-Furameera', finished:'Xumurame',
  type:'Gosa', title:'Mata-duree', subject:'Barumsa', action:'Tarkaanfiiwwan', approve:'Mirkaneessi', reject:'Didee',
  status:'Haala', date:'Guyyaa', score:'Qabxii', name:'Maqaa', present:'Argame', absent:'Hin-argamne', late:'Yeroo Darbe', excused:'Eeyyamame',
  save:'Olkaa\'i', download:'Buufadhu', join:'Kutaa Seeni', watch:'Daawwadhu', open:'Bani', no_data:'Daqiiqaa dhabamee jira.',
  teacher_d:'Daashboordii Barsiisaa', student_d:'Daashboordii Barataa', admin_d:'Daashboordii Adeemsa',
  welcome:'Baga Nagaan Dhuftan', verify_pay:'Kaffaltii Mirkaneessi', fee:'Kaffaltii', students:'barattoota',
  assign:'Hojiiwwan', quiz:'Qorannoolee', submit_work:'Hojii Galchi', enrolled:'Galmaa\'eera',
  footer_t:'GadaaICT Kutaalee Barsiisaa', footer_p:'Barumsi qulqulluu salphaa ta\'e daa\'imman Itoophiyaa bara dhufaa qopheessa.',
  quick:'Linkii Ariifachiisaa', contact:'Quunnamtii', rights:'Mirgi hundi seeraan eegama.',
  select_grade:'Kutaa kee fili', months:'ji\'a', already:'Akaawuntii qabdaa?', need_acc:'Akaawuntii hin-qabne?',
  total:'Waliigalaa', view:'Ilaali', mark:'Qabxii Kensiisi', feedback:'Yaada Kenni', gradebook:'Kitaaba Qabxii',
  pending_msg:'⏳ Akaawuntii kee mirkaneeffannaa eeggachaa jira. Maaloo 0912 251 318 irratti Telebirr\'iin kaffaltii xumuri.',
  ann_ph:'Beeksisa barreessi...', ann_t_ph:'Mata-duree beeksisa', all:'Hundi', active:'Aktivii', suspended:'Caccabame',
  sub_ok:'Milkaa\'inaan ergameera!', mark_ok:'Argamaan olkaa\'ameera!', appr_ok:'Barataan mirkanaa\'ee banameera!'
}};

const t = (k) => (I18N[state.lang] && I18N[state.lang][k]) || I18N.en[k] || k;

/* ---------------- STATE + DEMO DATA ---------------- */
const TELEBIRR_NUMBER = '0912 251 318';
const state = {
  lang: localStorage.getItem('g_lang') || 'en',
  user: JSON.parse(localStorage.getItem('g_user') || 'null'),
};
function saveState() {
  localStorage.setItem('g_lang', state.lang);
  if (state.user) localStorage.setItem('g_user', JSON.stringify(state.user));
}

const GRADES = [
  {id:0, name:'KG', fee:150}, {id:1, name:'Grade 1', fee:150}, {id:2, name:'Grade 2', fee:150},
  {id:3, name:'Grade 3', fee:150}, {id:4, name:'Grade 4', fee:200}, {id:5, name:'Grade 5', fee:200},
  {id:6, name:'Grade 6', fee:200}, {id:7, name:'Grade 7', fee:250}, {id:8, name:'Grade 8', fee:250},
  {id:9, name:'Grade 9', fee:300}, {id:10, name:'Grade 10', fee:300}, {id:11, name:'Grade 11', fee:350},
  {id:12, name:'Grade 12', fee:350},
];
const SUBJECT_NAMES = {
  en: ['Mathematics','English','Amharic','Afaan Oromoo','Science','Social Studies','ICT','Physics','Chemistry','Biology','History','Geography','Economics','Civics'],
  am: ['ሒሳብ','እንግሊዝኛ','አማርኛ','አፋን ኦሮሞ','ሳይንስ','ማህበራዊ','አይሲቲ','ፊዚክስ','ኬሚስትሪ','ባዮሎጂ','ታሪክ','ጂኦግራፊ','ኢኮኖሚክስ','አገርኛው አገልግሎት'],
  om: ['Herregaa','Ingilizii','Amaaraa','Afaan Oromoo','Saayinsii','Hawaasummaa','ICT','Fiiziksii','Keemistrii','Baayoolojii','Seenaa',"Ji'oo'grafii",'Ikoonoomiksii','Muummee Naannoo']
};

// Seed demo database (used when API_URL is empty)
function seedDemo() {
  if (localStorage.getItem('g_demo')) return;
  const demo = {
    users: [
      {id:1, name:'Admin Gadaa', email:'admin@gadaaict.com', password:'admin123', role:'admin', status:'active', phone:'0912000001', grade:null, lang:'en'},
      {id:2, name:'Obbo Gemechu Bekele', email:'teacher@gadaaict.com', password:'teach123', role:'teacher', status:'active', phone:'0912000002', grade:null, lang:'om'},
      {id:3, name:'Chaltu Abdissa', email:'student@gadaaict.com', password:'learn123', role:'student', status:'active', phone:'0912000003', grade:9, lang:'om'},
      {id:4, name:'Yonas Tesfaye', email:'yonas@mail.com', password:'x', role:'student', status:'pending', phone:'0912111222', grade:10, lang:'am'},
      {id:5, name:'Hana Girma', email:'hana@mail.com', password:'x', role:'student', status:'pending', phone:'0912333444', grade:5, lang:'en'},
    ],
    payments: [
      {id:1, studentId:4, amount:300, txn:'TXN88213391', months:1, status:'submitted', date:'2026-10-20'},
      {id:2, studentId:5, amount:200, txn:'TXN88214402', months:1, status:'submitted', date:'2026-10-21'},
      {id:3, studentId:3, amount:300, txn:'TXN88112233', months:1, status:'verified', date:'2026-10-01'},
    ],
    materials: [
      {id:1, subject:'Mathematics', grade:9, type:'video', title:'Algebra Basics - Chapter 1', url:'#', teacher:'Obbo Gemechu', lang:'om', date:'2026-10-15'},
      {id:2, subject:'Physics', grade:9, type:'pdf', title:'Grade 9 Physics Textbook (MoE)', url:'#', teacher:'Obbo Gemechu', lang:'en', date:'2026-10-14'},
      {id:3, subject:'English', grade:9, type:'ppt', title:'Tenses Presentation', url:'#', teacher:'Obbo Gemechu', lang:'en', date:'2026-10-12'},
      {id:4, subject:'Mathematics', grade:9, type:'audio', title:'Exam Tips Audio', url:'#', teacher:'Obbo Gemechu', lang:'am', date:'2026-10-10'},
    ],
    live: [
      {id:1, subject:'Mathematics', grade:9, title:'Live: Quadratic Equations', time:'Today 4:00 PM', url:'https://meet.jit.si/gadaaict-g9-math', status:'scheduled'},
      {id:2, subject:'Physics', grade:9, title:'Live: Motion & Forces', time:'Tomorrow 10:00 AM', url:'https://meet.jit.si/gadaaict-g9-phys', status:'scheduled'},
    ],
    attendance: [
      {session:'Mathematics - Oct 20', records:[{student:'Chaltu Abdissa', status:'present'}]},
    ],
    announcements: [
      {id:1, title:'Welcome to GadaaICT!', body:'New semester starts Monday. Check your live class schedule.', audience:'all', date:'2026-10-18'},
      {id:2, title:'Grade 9 Physics Quiz', body:'Quiz on Motion & Forces this Friday.', audience:'students', date:'2026-10-20'},
    ],
    submissions: [
      {id:1, assignment:'Math Homework #3', student:'Chaltu Abdissa', file:'homework3.pdf', status:'submitted', score:null},
    ],
  };
  localStorage.setItem('g_demo', JSON.stringify(demo));
}
seedDemo();
const db = () => JSON.parse(localStorage.getItem('g_demo'));
const saveDb = (d) => localStorage.setItem('g_demo', JSON.stringify(d));

/* ---------------- API LAYER ---------------- */
async function api(path, opts = {}) {
  if (!API_URL) throw new Error('Demo mode - no backend connected');
  const token = localStorage.getItem('g_token');
  const res = await fetch(API_URL + path, {
    ...opts,
    headers: { 'Content-Type': 'application/json',
               ...(token ? {Authorization: 'Bearer ' + token} : {}), ...(opts.headers||{}) },
  });
  if (!res.ok) throw new Error((await res.json().catch(()=> ({}))).detail || res.statusText);
  return res.json();
}

/* ---------------- UI HELPERS ---------------- */
function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll('.lang-switch button').forEach(b =>
    b.classList.toggle('active', b.dataset.lang === state.lang));
}
function setLang(l) { state.lang = l; saveState(); applyI18n(); }
function gradeName(id) { const g = GRADES.find(g => g.id === +id); return g ? g.name : '-'; }
function gradeFee(id) { const g = GRADES.find(g => g.id === +id); return g ? g.fee : 150; }
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function toast(msg, kind='ok') {
  let host = document.getElementById('toast-host');
  if (!host) { host = document.createElement('div'); host.id = 'toast-host';
    host.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:999;display:flex;flex-direction:column;gap:8px';
    document.body.appendChild(host); }
  const el = document.createElement('div');
  el.className = 'alert alert-' + kind;
  el.style.boxShadow = '0 6px 24px rgba(0,0,0,.15)';
  el.textContent = msg;
  host.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}
function requireRole(roles) {
  if (!state.user) { location.href = 'login.html'; return false; }
  if (!roles.includes(state.user.role)) { location.href = 'index.html'; return false; }
  return true;
}
function logout() { localStorage.removeItem('g_user'); localStorage.removeItem('g_token'); location.href = 'index.html'; }

const TYPE_ICON = { pdf:'📕', video:'🎬', audio:'🎧', ppt:'📊', link:'🔗', note:'📝' };
const STATUS_PILL = { active:'pill-green', pending:'pill-gold', suspended:'pill-red',
  verified:'pill-green', submitted:'pill-blue', present:'pill-green', absent:'pill-red',
  late:'pill-gold', excused:'pill-blue', scheduled:'pill-blue', live:'pill-red', done:'pill-green' };
const pill = (s) => `<span class="pill ${STATUS_PILL[s]||'pill-blue'}">${t(s)||s}</span>`;
