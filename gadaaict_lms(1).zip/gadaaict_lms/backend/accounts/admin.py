from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('email', 'first_name', 'role', 'phone', 'status', 'grade')
    list_filter = ('role', 'status', 'language', 'grade')
    search_fields = ('email', 'phone', 'first_name')
    actions = ['approve_students']

    fieldsets = UserAdmin.fieldsets + (
        ('GadaaICT', {'fields': ('role', 'phone', 'language', 'status',
                                 'grade', 'parent_phone', 'approved_by')}),
    )

    @admin.action(description='Approve selected students (grant access)')
    def approve_students(self, request, queryset):
        from django.utils import timezone
        queryset.update(status='active', approved_by=request.user, approved_at=timezone.now())
