from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.utils import timezone
from .models import User
from .serializers import RegisterSerializer, UserSerializer
from .permissions import IsAdmin


class RegisterView(generics.CreateAPIView):
    """Step 1: student self-registers -> account stays PENDING until payment approved."""
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


class EmailTokenSerializer(TokenObtainPairSerializer):
    username_field = 'email'


class LoginView(TokenObtainPairView):
    serializer_class = EmailTokenSerializer

    def post(self, request, *args, **kwargs):
        resp = super().post(request, *args, **kwargs)
        user = User.objects.get(email=request.data['email'])
        # Block login for students who have not been approved yet
        if user.role == 'student' and user.status != 'active':
            return Response({'detail': 'Account pending admin approval after payment.'},
                            status=status.HTTP_403_FORBIDDEN)
        resp.data['user'] = UserSerializer(user).data
        return resp


class MeView(APIView):
    def get(self, request):
        return Response(UserSerializer(request.user).data)


class PendingStudentsView(generics.ListAPIView):
    """Admin: list students waiting for payment approval."""
    serializer_class = UserSerializer
    permission_classes = [IsAdmin]

    def get_queryset(self):
        return User.objects.filter(role='student', status='pending').order_by('date_joined')


class ApproveStudentView(APIView):
    """Admin: approve (activate) or reject a student after verifying Telebirr payment."""
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        try:
            user = User.objects.get(pk=pk, role='student')
        except User.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        action = request.data.get('action')   # 'approve' | 'reject'
        if action == 'approve':
            user.status = 'active'
            user.approved_by = request.user
            user.approved_at = timezone.now()
            user.save()
            return Response({'detail': f'{user.first_name} approved. Access granted.'})
        user.status = 'suspended'
        user.save()
        return Response({'detail': 'Student rejected/suspended.'})


class ParentChildrenView(APIView):
    """GET /api/auth/parent/children/ -> children linked via parent_phone."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from academics.models import Enrollment
        from content.models import Attendance
        from payments.models import Payment
        from assessment.models import Submission, Mark
        if request.user.role not in ('parent', 'admin'):
            return Response({'detail': 'Parents only.'}, status=403)
        children = User.objects.filter(parent_phone=request.user.phone, role='student')
        data = []
        for ch in children:
            att = Attendance.objects.filter(student=ch)
            total = att.count()
            present = att.filter(status__in=['present', 'excused']).count()
            subs = Submission.objects.filter(student=ch)
            marks = [s.mark.score for s in subs.select_related('mark') if hasattr(s, 'mark')]
            data.append({
                'id': ch.id, 'name': ch.first_name, 'grade': ch.grade.name if ch.grade else None,
                'status': ch.status,
                'attendance_rate': round(present / total * 100) if total else None,
                'subjects_enrolled': Enrollment.objects.filter(student=ch, status='active').count(),
                'avg_score': round(sum(marks) / len(marks), 1) if marks else None,
                'last_payment': (Payment.objects.filter(student=ch, status='verified')
                                 .values('amount', 'created_at').first()),
            })
        return Response(data)
