from rest_framework.permissions import BasePermission


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        u = request.user
        return u.is_authenticated and (u.is_superuser or u.role == 'admin')


class IsTeacher(BasePermission):
    def has_permission(self, request, view):
        u = request.user
        return u.is_authenticated and (u.role == 'teacher' or u.is_superuser
                                       or u.role == 'admin')


class IsStudent(BasePermission):
    def has_permission(self, request, view):
        u = request.user
        return u.is_authenticated and u.role == 'student' and u.status == 'active'
