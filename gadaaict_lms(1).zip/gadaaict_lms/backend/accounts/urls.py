from django.urls import path
from .views import (RegisterView, LoginView, MeView, PendingStudentsView,
                    ApproveStudentView, ParentChildrenView)

urlpatterns = [
    path('register/', RegisterView.as_view()),
    path('login/', LoginView.as_view()),
    path('me/', MeView.as_view()),
    path('pending/', PendingStudentsView.as_view()),
    path('<int:pk>/approve/', ApproveStudentView.as_view()),
    path('parent/children/', ParentChildrenView.as_view()),
]
