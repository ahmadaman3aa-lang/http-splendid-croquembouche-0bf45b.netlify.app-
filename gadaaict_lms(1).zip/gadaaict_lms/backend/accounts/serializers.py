from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import User

User = get_user_model()


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)
    grade_id = serializers.IntegerField(required=False, allow_null=True)

    class Meta:
        model = User
        fields = ['email', 'username', 'full_name', 'password', 'phone',
                  'language', 'grade_id', 'parent_phone']
        extra_kwargs = {'full_name': {'required': True}}

    def create(self, validated):
        from academics.models import Grade
        grade = None
        if validated.get('grade_id'):
            grade = Grade.objects.filter(id=validated['grade_id']).first()
        user = User.objects.create_user(
            username=validated['username'],
            email=validated['email'],
            password=validated['password'],
            phone=validated['phone'],
            language=validated.get('language', 'en'),
            role='student',
            status='pending',          # active ONLY after admin approves payment
            grade=grade,
            parent_phone=validated.get('parent_phone', ''),
        )
        user.first_name = validated['full_name']
        user.save()
        return user


class UserSerializer(serializers.ModelSerializer):
    grade_name = serializers.CharField(source='grade.name', read_only=True)

    class Meta:
        model = User
        fields = ['id', 'email', 'username', 'first_name', 'phone', 'role',
                  'language', 'status', 'grade', 'grade_name', 'approved_at']
        read_only_fields = ['role', 'status', 'approved_at']
