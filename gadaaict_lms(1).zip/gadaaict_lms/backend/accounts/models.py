from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Custom user: email login + role built in."""
    class Role(models.TextChoices):
        STUDENT = 'student', 'Student'
        TEACHER = 'teacher', 'Teacher'
        ADMIN = 'admin', 'Admin'
        PARENT = 'parent', 'Parent'

    class Lang(models.TextChoices):
        EN = 'en', 'English'
        AM = 'am', 'Amharic'
        OM = 'om', 'Afaan Oromoo'

    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending payment approval'
        ACTIVE = 'active', 'Active'
        SUSPENDED = 'suspended', 'Suspended'

    email = models.EmailField(unique=True)
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.STUDENT)
    phone = models.CharField(max_length=20, unique=True)   # Telebirr number
    language = models.CharField(max_length=2, choices=Lang.choices, default=Lang.EN)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    grade = models.ForeignKey('academics.Grade', null=True, blank=True,
                              on_delete=models.SET_NULL, related_name='students')
    parent_phone = models.CharField(max_length=20, blank=True)
    approved_by = models.ForeignKey('self', null=True, blank=True,
                                    on_delete=models.SET_NULL, related_name='approved_students')
    approved_at = models.DateTimeField(null=True, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'phone']

    @property
    def is_student(self): return self.role == self.Role.STUDENT
    @property
    def is_teacher(self): return self.role == self.Role.TEACHER
    @property
    def is_admin_role(self): return self.role == self.Role.ADMIN or self.is_superuser
