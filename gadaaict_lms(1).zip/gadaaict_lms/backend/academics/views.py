from rest_framework import viewsets, permissions
from .models import Grade, Subject, Enrollment
from .serializers import GradeSerializer, SubjectSerializer, EnrollmentSerializer
from accounts.permissions import IsAdmin


class GradeViewSet(viewsets.ModelViewSet):
    queryset = Grade.objects.all()
    serializer_class = GradeSerializer

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAdmin()]
        return [permissions.AllowAny()]      # public: pricing page needs fees


class SubjectViewSet(viewsets.ModelViewSet):
    serializer_class = SubjectSerializer

    def get_queryset(self):
        qs = Subject.objects.select_related('grade')
        grade_id = self.request.query_params.get('grade')
        return qs.filter(grade_id=grade_id) if grade_id else qs

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAdmin()]
        return [permissions.IsAuthenticated()]


class EnrollmentViewSet(viewsets.ModelViewSet):
    serializer_class = EnrollmentSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Enrollment.objects.select_related('subject__grade')
        if u.role == 'student':
            return qs.filter(student=u)
        return qs                           # teachers/admin see all

    def perform_create(self, serializer):
        serializer.save(student=self.request.user)
