"""Seed grades + subjects: python manage.py seed"""
from django.core.management.base import BaseCommand
from academics.models import Grade, Subject

SUBJECTS = {
    'lower': ['Mathematics', 'English', 'Amharic', 'Afaan Oromoo', 'Science',
              'Social Studies', 'ICT', 'Art'],
    'middle': ['Mathematics', 'English', 'Amharic', 'Afaan Oromoo', 'Physics',
               'Chemistry', 'Biology', 'History', 'Geography', 'ICT', 'Civics'],
    'upper': ['Mathematics', 'English', 'Amharic', 'Afaan Oromoo', 'Physics',
              'Chemistry', 'Biology', 'History', 'Geography', 'Economics',
              'Business', 'ICT', 'Civics'],
}
AM = {'Mathematics':'ሒሳብ','English':'እንግሊዝኛ','Amharic':'አማርኛ','Afaan Oromoo':'አፋን ኦሮሞ',
      'Science':'ሳይንስ','Social Studies':'ማህበራዊ ጥናት','ICT':'አይሲቲ','Art':'ኪነ ጥበብ',
      'Physics':'ፊዚክስ','Chemistry':'ኬሚስትሪ','Biology':'ባዮሎጂ','History':'ታሪክ',
      'Geography':'ጂኦግራፊ','Civics':'አገርኛው አገልግሎት','Economics':'ኢኮኖሚክስ','Business':'ቢዝነስ'}
OM = {'Mathematics':'Herregaa','English':'Ingilizii','Amharic':'Amaaraa','Afaan Oromoo':'Afaan Oromoo',
      'Science':'Saayinsii','Social Studies':'Hawaasummaa','ICT':'ICT','Art':'Kitaaba',
      'Physics':'Fiiziksii','Chemistry':'Keemistrii','Biology':'Baayoolojii','History':'Seenaa',
      'Geography':"Ji'oo'grafii",'Civics':'Muummee Naannoo','Economics':'Ikoonoomiksii','Business':'Bussinesii'}
FEES = {0:150, 1:150, 2:150, 3:150, 4:200, 5:200, 6:200, 7:250, 8:250, 9:300, 10:300, 11:350, 12:350}


class Command(BaseCommand):
    help = 'Create KG-Grade 12 with subjects and monthly fees'

    def handle(self, *args, **options):
        for i in range(0, 13):
            name = 'KG' if i == 0 else f'Grade {i}'
            g, _ = Grade.objects.get_or_create(name=name, defaults={
                'level_order': i, 'monthly_fee': FEES[i]})
            bucket = 'lower' if i <= 4 else ('middle' if i <= 8 else 'upper')
            for s in SUBJECTS[bucket]:
                Subject.objects.get_or_create(grade=g, name_en=s, defaults={
                    'name_am': AM.get(s, s), 'name_om': OM.get(s, s)})
        self.stdout.write(self.style.SUCCESS(
            'Seeded 13 grades with subjects (EN/AM/OM) and Telebirr fees.'))
