from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import GradeViewSet, SubjectViewSet, EnrollmentViewSet

router = DefaultRouter()
router.register('grades', GradeViewSet)
router.register('subjects', SubjectViewSet)
router.register('enrollments', EnrollmentViewSet)
urlpatterns = [path('', include(router.urls))]
