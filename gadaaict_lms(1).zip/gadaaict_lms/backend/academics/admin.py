from django.contrib import admin
from .models import Grade, Subject, Enrollment

admin.site.register(Grade)
admin.site.register(Subject)
admin.site.register(Enrollment)
