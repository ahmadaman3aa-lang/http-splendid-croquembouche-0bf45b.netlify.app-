from rest_framework import serializers
from .models import Grade, Subject, Enrollment


class GradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grade
        fields = '__all__'


class SubjectSerializer(serializers.ModelSerializer):
    grade_name = serializers.CharField(source='grade.name', read_only=True)

    class Meta:
        model = Subject
        fields = ['id', 'grade', 'grade_name', 'name_en', 'name_am', 'name_om']


class EnrollmentSerializer(serializers.ModelSerializer):
    subject_name = serializers.CharField(source='subject.name_en', read_only=True)
    grade_name = serializers.CharField(source='subject.grade.name', read_only=True)

    class Meta:
        model = Enrollment
        fields = ['id', 'student', 'subject', 'subject_name', 'grade_name',
                  'status', 'progress', 'enrolled_at']
        read_only_fields = ['student', 'progress']
