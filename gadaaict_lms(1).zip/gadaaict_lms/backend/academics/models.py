from django.db import models


class Grade(models.Model):
    name = models.CharField(max_length=20, unique=True)      # KG, Grade 1 ... Grade 12
    level_order = models.PositiveSmallIntegerField()         # 0=KG, 1..12
    monthly_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        ordering = ['level_order']

    def __str__(self):
        return self.name


class Subject(models.Model):
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, related_name='subjects')
    name_en = models.CharField(max_length=120)
    name_am = models.CharField(max_length=120)
    name_om = models.CharField(max_length=120)

    class Meta:
        unique_together = ('grade', 'name_en')

    def name(self, lang='en'):
        return {'en': self.name_en, 'am': self.name_am, 'om': self.name_om}.get(lang, self.name_en)

    def __str__(self):
        return f'{self.grade.name} - {self.name_en}'


class Enrollment(models.Model):
    student = models.ForeignKey('accounts.User', on_delete=models.CASCADE,
                                related_name='enrollments', limit_choices_to={'role': 'student'})
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='enrollments')
    status = models.CharField(max_length=12, default='active',
                              choices=[('active', 'Active'), ('completed', 'Completed'),
                                       ('dropped', 'Dropped')])
    progress = models.PositiveSmallIntegerField(default=0)   # 0-100
    enrolled_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'subject')

    def __str__(self):
        return f'{self.student} -> {self.subject}'
