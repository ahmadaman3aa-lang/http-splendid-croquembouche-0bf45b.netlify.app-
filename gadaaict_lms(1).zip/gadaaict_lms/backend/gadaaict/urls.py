from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('accounts.urls')),
    path('api/academics/', include('academics.urls')),
    path('api/payments/', include('payments.urls')),
    path('api/content/', include('content.urls')),
    path('api/assessment/', include('assessment.urls')),
    path('api/comms/', include('comms.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
