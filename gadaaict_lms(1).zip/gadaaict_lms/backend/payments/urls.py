from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PaymentViewSet, VerifyPaymentView, TelebirrWebhookView

router = DefaultRouter()
router.register('', PaymentViewSet)
urlpatterns = [path('', include(router.urls)),
               path('<int:pk>/verify/', VerifyPaymentView.as_view()),
               path('telebirr/webhook/', TelebirrWebhookView.as_view())]
