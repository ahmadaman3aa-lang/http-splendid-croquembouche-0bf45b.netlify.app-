from django.db import models
from django.conf import settings


class Payment(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = 'submitted', 'Submitted'
        VERIFIED = 'verified', 'Verified'
        REJECTED = 'rejected', 'Rejected'

    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='payments')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    months_paid = models.PositiveSmallIntegerField(default=1)
    telebirr_txn = models.CharField(max_length=60)          # transaction reference
    screenshot = models.ImageField(upload_to='payments/', blank=True, null=True)
    status = models.CharField(max_length=10, choices=Status.choices,
                              default=Status.SUBMITTED)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                    on_delete=models.SET_NULL, related_name='reviewed_payments')
    reviewed_at = models.DateTimeField(null=True, blank=True)
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.student} - {self.amount} ETB ({self.status})'
