"""
Telebirr SDP (Service Delivery Platform) integration - Phase 4.
Sign up as a merchant with Ethio Telecom SDP to get:
  MERCHANT_ID, FABRIC_APP_ID, APP_SECRET, SHORT_CODE, PUBLIC_KEY

Flow:
  1. Backend creates a payment order -> Telebirr returns a ussd push / web URL
  2. Student authorizes on their phone
  3. Telebirr calls WEBHOOK_URL -> we verify & activate the student automatically
"""
import base64, json, time, uuid
from dataclasses import dataclass
from decouple import config

TELEBIRR = {
    'merchant_id': config('TB_MERCHANT_ID', default=''),
    'fabric_app_id': config('TB_FABRIC_APP_ID', default=''),
    'app_secret': config('TB_APP_SECRET', default=''),
    'short_code': config('TB_SHORT_CODE', default=''),
    'public_key': config('TB_PUBLIC_KEY', default=''),
    'base_url': config('TB_BASE_URL', default='https://api.sandbox.telebirr.com'),
    'webhook_url': config('TB_WEBHOOK_URL', default='https://yourdomain.com/api/payments/telebirr/webhook/'),
}


@dataclass
class TelebirrOrder:
    amount: float
    phone: str
    reference: str          # unique order id (store in Payment.telebirr_txn)
    callback_url: str = TELEBIRR['webhook_url']


def _encrypt_payload(payload: str) -> str:
    """RSA encrypt with Telebirr public key (pycryptodome)."""
    from Crypto.PublicKey import RSA
    from Crypto.Cipher import PKCS1_v1_5
    key = RSA.import_key(TELEBIRR['public_key'])
    cipher = PKCS1_v1_5.new(key)
    return base64.b64encode(cipher.encrypt(payload.encode())).decode()


def create_order(order: TelebirrOrder) -> dict:
    """POST /payment/v1/merchant/preOrder -> returns payment URL / ussd code."""
    import requests
    payload = {
        'merchantAppId': TELEBIRR['fabric_app_id'],
        'merchantCode': TELEBIRR['merchant_id'],
        'nonce': str(uuid.uuid4()).replace('-', ''),
        'timestamp': str(int(time.time() * 1000)),
        'shortCode': TELEBIRR['short_code'],
        'subject': 'GadaaICT subscription',
        'toServiceCode': '705',
        'notifyUrl': order.callback_url,
        'returnUrl': order.callback_url,
        'transactionNo': order.reference,
        'amount': str(order.amount),
        'phone': order.phone,
    }
    body = {
        'appId': TELEBIRR['fabric_app_id'],
        'merchOrderId': order.reference,
        'prepayId': '',
        'payeeUid': order.phone,
        'tradeType': 'InApp',
        'timestamp': payload['timestamp'],
        'nonce': payload['nonce'],
        'sign': _encrypt_payload(json.dumps(payload)),
        'body': _encrypt_payload(json.dumps(payload)),
    }
    r = requests.post(f"{TELEBIRR['base_url']}/payment/v1/merchant/preOrder",
                      json=body, timeout=30)
    r.raise_for_status()
    return r.json()


def verify_callback(data: dict) -> tuple[bool, str, float]:
    """Verify the webhook fields Telebirr sends back.
    Returns (is_success, transaction_no, amount).
    Production: also verify RSA signature with Telebirr certificate."""
    tx = data.get('transactionNo') or data.get('merchOrderId', '')
    amount = float(data.get('totalAmount', 0) or 0)
    paid = str(data.get('tradeStatus', '')).upper() in ('SUCCESS', '2')
    return paid, tx, amount
