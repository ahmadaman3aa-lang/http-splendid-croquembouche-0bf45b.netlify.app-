from rest_framework import serializers
from .models import Payment


class PaymentSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.first_name', read_only=True)
    student_email = serializers.CharField(source='student.email', read_only=True)

    class Meta:
        model = Payment
        fields = ['id', 'student', 'student_name', 'student_email', 'amount',
                  'months_paid', 'telebirr_txn', 'screenshot', 'status', 'note',
                  'created_at', 'reviewed_at']
        read_only_fields = ['status', 'reviewed_at']

    def validate_telebirr_txn(self, value):
        if Payment.objects.filter(telebirr_txn=value).exists():
            raise serializers.ValidationError('This transaction ID was already used.')
        return value
