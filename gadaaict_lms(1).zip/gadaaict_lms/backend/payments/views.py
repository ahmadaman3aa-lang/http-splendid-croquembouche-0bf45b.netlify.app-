from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from django.utils import timezone
from .models import Payment
from .serializers import PaymentSerializer
from accounts.permissions import IsAdmin


class PaymentViewSet(viewsets.ModelViewSet):
    """Student submits payment proof; admin reviews/verifies."""
    serializer_class = PaymentSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Payment.objects.select_related('student')
        if u.role == 'student':
            return qs.filter(student=u)
        return qs

    def get_permissions(self):
        if self.action in ('list', 'retrieve', 'destroy'):
            return [IsAdmin()] if self.request.user.role != 'student' else []
        return super().get_permissions()

    def perform_create(self, serializer):
        serializer.save(student=self.request.user, status='submitted')


class VerifyPaymentView(APIView):
    """Admin verifies Telebirr payment -> activates the student automatically."""
    permission_classes = [IsAdmin]

    def post(self, request, pk):
        try:
            payment = Payment.objects.select_related('student').get(pk=pk)
        except Payment.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        action = request.data.get('action')     # 'verify' | 'reject'
        payment.reviewed_by = request.user
        payment.reviewed_at = timezone.now()
        if action == 'verify':
            payment.status = 'verified'
            payment.note = request.data.get('note', '')
            payment.save()
            student = payment.student
            student.status = 'active'
            student.approved_by = request.user
            student.approved_at = timezone.now()
            student.save()
            # SMS notification (trilingual) - never crashes the request
            try:
                from comms.sms import send_sms, sms_payment_approved
                send_sms(student.phone,
                         sms_payment_approved(student.first_name, student.language))
            except Exception:
                pass
            return Response({'detail': 'Payment verified. Student activated.'})
        payment.status = 'rejected'
        payment.note = request.data.get('note', 'Payment could not be verified.')
        payment.save()
        return Response({'detail': 'Payment rejected.'})


class TelebirrWebhookView(APIView):
    """Telebirr SDP callback: auto-verify payment + activate student (Phase 4)."""
    permission_classes = [AllowAny]     # Telebirr calls this; verify payload instead

    def post(self, request):
        from .telebirr import verify_callback
        from accounts.models import User
        ok, tx, amount = verify_callback(request.data)
        if not ok:
            return Response({'detail': 'payment not successful'}, status=200)
        try:
            payment = Payment.objects.select_related('student').get(telebirr_txn=tx)
        except Payment.DoesNotExist:
            return Response({'detail': 'unknown transaction'}, status=200)
        payment.status = 'verified'
        payment.reviewed_at = timezone.now()
        payment.save()
        student = payment.student
        student.status = 'active'
        student.approved_at = timezone.now()
        student.save()
        try:
            from comms.sms import send_sms, sms_payment_approved
            send_sms(student.phone, sms_payment_approved(student.first_name, student.language))
        except Exception:
            pass
        return Response({'detail': 'activated'})
