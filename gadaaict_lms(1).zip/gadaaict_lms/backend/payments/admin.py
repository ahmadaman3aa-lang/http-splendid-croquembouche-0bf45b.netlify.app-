from django.contrib import admin
from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('student', 'amount', 'telebirr_txn', 'status', 'created_at')
    list_filter = ('status',)
    actions = ['mark_verified']

    @admin.action(description='Verify payments & activate students')
    def mark_verified(self, request, queryset):
        from django.utils import timezone
        for p in queryset:
            p.status = 'verified'; p.reviewed_by = request.user
            p.reviewed_at = timezone.now(); p.save()
            p.student.status = 'active'; p.student.approved_by = request.user
            p.student.approved_at = timezone.now(); p.student.save()
