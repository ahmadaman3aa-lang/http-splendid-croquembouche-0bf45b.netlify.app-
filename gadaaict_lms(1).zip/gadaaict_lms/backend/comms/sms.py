"""
SMS notifications via Ethiopian gateways (Eskalate / Infobip).
Set SMS_PROVIDER, SMS_API_KEY, SMS_SENDER, SMS_API_URL in .env
"""
import requests
from decouple import config

SMS_CONFIG = {
    'api_key': config('SMS_API_KEY', default=''),
    'sender': config('SMS_SENDER', default='GadaaICT'),
    'api_url': config('SMS_API_URL', default='https://sms-gateway.example/send'),
}


def send_sms(phone: str, message: str) -> bool:
    """Send one SMS. Phone format: 2519xxxxxxxx or 09xxxxxxxx."""
    phone = phone.strip().replace(' ', '')
    if phone.startswith('0'):
        phone = '251' + phone[1:]
    try:
        r = requests.post(SMS_CONFIG['api_url'], json={
            'api_key': SMS_CONFIG['api_key'],
            'sender': SMS_CONFIG['sender'],
            'to': phone,
            'message': message,
        }, timeout=20)
        return r.ok
    except Exception:
        return False  # never crash the main flow because of SMS


def sms_payment_approved(name: str, lang: str = 'en') -> str:
    msgs = {
        'en': f"Dear {name}, your payment is verified. Your GadaaICT account is ACTIVE. Log in and start learning!",
        'am': f"ውድ {name}፣ ክፍያዎ ተረጋግጧል። የጋዳአይሲቲ አካውንትዎ ንቁ ነው። ገብተው ትምህርት ይጀምሩ!",
        'om': f"Obbo/Adde {name}, kaffaltiin kee mirkanaa'eera. Akaawuntii GadaaICT kee banameera. Seeni barachuu jalqabi!",
    }
    return msgs.get(lang, msgs['en'])


def sms_live_class_reminder(name: str, title: str, time_str: str, lang: str = 'en') -> str:
    msgs = {
        'en': f"Hi {name}, live class '{title}' starts at {time_str}. Join from your GadaaICT dashboard.",
        'am': f"ሰላም {name}፣ የቀጥታ ክፍል '{title}' በ{time_str} ይጀምራል። ከዳሽቦርድዎ ይቀላቀሉ።",
        'om': f"Akkam {name}, kutaa toora interneetii '{title}' sa'aatii {time_str} eegalama. Daashboordii kee irraa makami.",
    }
    return msgs.get(lang, msgs['en'])
