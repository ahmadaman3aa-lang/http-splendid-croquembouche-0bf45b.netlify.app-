from django.contrib import admin
from .models import Announcement, Certificate

admin.site.register(Announcement)
admin.site.register(Certificate)
