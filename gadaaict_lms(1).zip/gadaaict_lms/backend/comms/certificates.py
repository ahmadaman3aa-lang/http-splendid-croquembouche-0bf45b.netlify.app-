"""
Certificate PDF generator (trilingual) - uses reportlab.
pip install reportlab  (add to requirements.txt)
"""
import io, uuid
from datetime import date


def _font():
    """Register a Unicode TTF that supports Ethiopic + Latin.
    Download: AbyssinicaSIL-Regular.ttf (SIL OFL license) -> backend/assets/fonts/"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from pathlib import Path
    font_path = Path(__file__).resolve().parent.parent / 'assets/fonts/AbyssinicaSIL-Regular.ttf'
    name = 'Ethiopic'
    if font_path.exists():
        try:
            pdfmetrics.registerFont(TTFont(name, str(font_path)))
            return name
        except Exception:
            pass
    return 'Helvetica'   # fallback: Latin only


def generate_certificate(student_name: str, subject: str, grade: str,
                         lang: str = 'en', serial: str = None) -> bytes:
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    serial = serial or f'GADAA-{uuid.uuid4().hex[:12].upper()}'
    L = {
        'en': {'title': 'Certificate of Completion', 'awarded': 'This certificate is awarded to',
               'for': f'for successfully completing', 'grade': 'Grade', 'date': 'Date of issue',
               'dir': 'Director', 'org': 'GadaaICT Class Tutorial'},
        'am': {'title': 'የማጠናቀቂያ ምስክር ወረቀት', 'awarded': 'ይህ ምስክር ወረቀት የሚሰጥው ለ',
               'for': 'በተሳካ ሁኔታ ማጠናቀቅ ስለቻለው/ች', 'grade': 'ክፍል', 'date': 'የተሰጠበት ቀን',
               'dir': 'ዳይሬክተር', 'org': 'ጋዳአይሲቲ ክላስ ቱቶሪያል'},
        'om': {'title': 'Ragaa Xumuraa', 'awarded': 'Ragaan kun kennamaaf',
               'for': 'xumuruuf danda\'eettiif', 'grade': 'Kutaa', 'date': 'Guyyaa Kennamaa',
               'dir': 'Direktarii', 'org': 'GadaaICT Kutaalee Barsiisaa'},
    }[lang if lang in ('en', 'am', 'om') else 'en']

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=landscape(A4))
    W, H = landscape(A4)
    GREEN, GOLD, DARK = '#078930', '#f9b40f', '#046a24'
    font = _font()

    # border
    c.setStrokeColor(GREEN); c.setLineWidth(4)
    c.rect(12*mm, 12*mm, W-24*mm, H-24*mm)
    c.setStrokeColor(GOLD); c.setLineWidth(1.5)
    c.rect(16*mm, 16*mm, W-32*mm, H-32*mm)

    # logo circle
    c.setFillColor(GREEN); c.circle(W/2, H-42*mm, 14*mm, fill=1, stroke=0)
    c.setFillColor(GOLD); c.circle(W/2, H-42*mm, 10*mm, fill=1, stroke=0)
    c.setFillColor(GREEN); c.setFont('Helvetica-Bold', 20)
    c.drawCentredString(W/2, H-45.5*mm, 'G')

    # texts
    c.setFillColor(DARK); c.setFont(font, 30)
    c.drawCentredString(W/2, H-68*mm, L['title'])
    c.setFont(font, 13); c.setFillColor('#444')
    c.drawCentredString(W/2, H-80*mm, L['org'])
    c.setFont(font, 14)
    c.drawCentredString(W/2, H-98*mm, L['awarded'])

    c.setFillColor(DARK); c.setFont(font, 34)
    c.drawCentredString(W/2, H-116*mm, student_name)

    c.setStrokeColor(GOLD); c.setLineWidth(1.5)
    c.line(W/2-70*mm, H-122*mm, W/2+70*mm, H-122*mm)

    c.setFillColor('#444'); c.setFont(font, 14)
    c.drawCentredString(W/2, H-132*mm, f"{L['for']} {subject}  ·  {L['grade']} {grade}")

    c.setFont(font, 10); c.setFillColor('#666')
    c.drawString(30*mm, 30*mm, f"{L['date']}: {date.today():%d/%m/%Y}")
    c.drawRightString(W-30*mm, 30*mm, f"{L['dir']} ____________")
    c.drawCentredString(W/2, 22*mm, f"SN: {serial}")

    c.showPage(); c.save()
    return buf.getvalue()
