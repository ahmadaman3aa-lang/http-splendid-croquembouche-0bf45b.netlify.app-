from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AnnouncementViewSet, CertificateViewSet, CertificatePDFView

router = DefaultRouter()
router.register('announcements', AnnouncementViewSet)
router.register('certificates', CertificateViewSet)
urlpatterns = [path('', include(router.urls)),
               path('certificates/<int:pk>/pdf/', CertificatePDFView.as_view())]
