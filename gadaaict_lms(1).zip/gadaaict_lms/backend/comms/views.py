from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import HttpResponse
from .models import Announcement, Certificate
from .serializers import AnnouncementSerializer, CertificateSerializer
from accounts.permissions import IsAdmin, IsTeacher, IsStudent

from rest_framework.decorators import action


class AnnouncementViewSet(viewsets.ModelViewSet):
    serializer_class = AnnouncementSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Announcement.objects.select_related('author', 'grade')
        if u.role == 'student':
            return qs.filter(models_q(u))
        return qs

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsTeacher()]
        return [permissions.IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)


def models_q(user):
    from django.db.models import Q
    return (Q(audience='all') | Q(audience='students')
            | Q(audience='grade', grade=user.grade))


class CertificateViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = CertificateSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Certificate.objects.select_related('student', 'subject')
        if u.role == 'student':
            return qs.filter(student=u)
        return qs


class CertificatePDFView(APIView):
    """GET /api/comms/certificates/<id>/pdf/ -> download trilingual PDF."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        from .certificates import generate_certificate
        cert = Certificate.objects.select_related('student', 'subject__grade').get(pk=pk)
        if request.user.role == 'student' and cert.student != request.user:
            return Response({'detail': 'Forbidden.'}, status=403)
        pdf = generate_certificate(
            student_name=cert.student.first_name,
            subject=cert.subject.name(request.user.language),
            grade=cert.subject.grade.name,
            lang=cert.student.language,
            serial=cert.serial_no)
        resp = HttpResponse(pdf, content_type='application/pdf')
        resp['Content-Disposition'] = f'attachment; filename="certificate-{cert.serial_no}.pdf"'
        return resp
