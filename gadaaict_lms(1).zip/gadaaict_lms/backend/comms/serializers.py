from rest_framework import serializers
from .models import Announcement, Certificate


class AnnouncementSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source='author.first_name', read_only=True)

    class Meta:
        model = Announcement
        fields = ['id', 'author', 'author_name', 'title', 'body', 'audience',
                  'grade', 'language', 'created_at']
        read_only_fields = ['author']


class CertificateSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.first_name', read_only=True)
    subject_name = serializers.CharField(source='subject.name_en', read_only=True)

    class Meta:
        model = Certificate
        fields = ['id', 'student', 'student_name', 'subject', 'subject_name',
                  'serial_no', 'issued_at']
