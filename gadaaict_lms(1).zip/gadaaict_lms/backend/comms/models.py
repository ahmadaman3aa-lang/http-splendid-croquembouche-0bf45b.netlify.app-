from django.db import models
from django.conf import settings


class Announcement(models.Model):
    class Audience(models.TextChoices):
        ALL = 'all', 'Everyone'
        STUDENTS = 'students', 'Students'
        TEACHERS = 'teachers', 'Teachers'
        GRADE = 'grade', 'Specific Grade'

    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    body = models.TextField()
    audience = models.CharField(max_length=10, choices=Audience.choices, default='all')
    grade = models.ForeignKey('academics.Grade', null=True, blank=True,
                              on_delete=models.SET_NULL)
    language = models.CharField(max_length=2, default='en')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class Certificate(models.Model):
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='certificates')
    subject = models.ForeignKey('academics.Subject', on_delete=models.CASCADE)
    serial_no = models.CharField(max_length=40, unique=True)
    issued_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.serial_no:
            import uuid
            self.serial_no = f'GADAA-{uuid.uuid4().hex[:12].upper()}'
        super().save(*args, **kwargs)
