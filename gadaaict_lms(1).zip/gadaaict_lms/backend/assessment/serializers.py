from rest_framework import serializers
from .models import Assignment, Submission, Mark, Quiz, Question, QuizAttempt


class AssignmentSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.first_name', read_only=True)

    class Meta:
        model = Assignment
        fields = ['id', 'subject', 'teacher', 'teacher_name', 'title', 'description',
                  'max_score', 'file', 'due_at', 'created_at']
        read_only_fields = ['teacher']


class MarkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mark
        fields = ['id', 'submission', 'score', 'feedback', 'marked_at']
        read_only_fields = ['marked_at']


class SubmissionSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.first_name', read_only=True)
    mark = MarkSerializer(read_only=True)

    class Meta:
        model = Submission
        fields = ['id', 'assignment', 'student', 'student_name', 'file',
                  'text_answer', 'submitted_at', 'mark']


class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'quiz', 'text', 'options', 'marks']   # answer hidden from students
        read_only_fields = ['quiz']


class QuizSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, read_only=True)

    class Meta:
        model = Quiz
        fields = ['id', 'subject', 'teacher', 'title', 'total_marks', 'created_at', 'questions']
        read_only_fields = ['teacher']


class QuizAttemptSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuizAttempt
        fields = ['id', 'quiz', 'answers', 'score', 'taken_at']
        read_only_fields = ['score', 'taken_at']
