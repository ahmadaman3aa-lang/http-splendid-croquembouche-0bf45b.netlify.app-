from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (AssignmentViewSet, SubmissionViewSet, MarkingView,
                    QuizViewSet, QuestionViewSet, TakeQuizView)

router = DefaultRouter()
router.register('assignments', AssignmentViewSet)
router.register('submissions', SubmissionViewSet)
router.register('quizzes', QuizViewSet)
router.register('questions', QuestionViewSet)
urlpatterns = [path('', include(router.urls)),
               path('mark/', MarkingView.as_view()),
               path('quizzes/<int:pk>/take/', TakeQuizView.as_view())]
