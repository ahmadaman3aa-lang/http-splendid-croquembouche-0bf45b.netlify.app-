from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from decimal import Decimal
from .models import Assignment, Submission, Mark, Quiz, Question, QuizAttempt
from .serializers import (AssignmentSerializer, SubmissionSerializer, MarkSerializer,
                          QuizSerializer, QuestionSerializer, QuizAttemptSerializer)
from accounts.permissions import IsTeacher, IsAdmin


class AssignmentViewSet(viewsets.ModelViewSet):
    serializer_class = AssignmentSerializer
    filterset_fields = ['subject']

    def get_queryset(self):
        return Assignment.objects.select_related('subject', 'teacher')

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsTeacher()]
        return [permissions.IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)


class SubmissionViewSet(viewsets.ModelViewSet):
    serializer_class = SubmissionSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Submission.objects.select_related('student', 'assignment')
        if u.role == 'student':
            return qs.filter(student=u)
        return qs

    def get_permissions(self):
        if self.request.user.role == 'student':
            return [permissions.IsAuthenticated()]
        return [IsTeacher()]

    def perform_create(self, serializer):
        serializer.save(student=self.request.user)


class MarkingView(APIView):
    """Teacher grades a submission -> creates/updates Mark record."""
    permission_classes = [IsTeacher]

    def post(self, request):
        sub_id = request.data.get('submission_id')
        score = Decimal(str(request.data.get('score')))
        feedback = request.data.get('feedback', '')
        try:
            sub = Submission.objects.get(pk=sub_id)
        except Submission.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        if score > sub.assignment.max_score:
            return Response({'detail': 'Score exceeds max.'}, status=400)
        mark, _ = Mark.objects.update_or_create(
            submission=sub,
            defaults={'score': score, 'feedback': feedback, 'marked_by': request.user})
        return Response({'detail': 'Marked.', 'mark_id': mark.id})


class QuizViewSet(viewsets.ModelViewSet):
    serializer_class = QuizSerializer
    filterset_fields = ['subject']

    def get_queryset(self):
        return Quiz.objects.prefetch_related('questions')

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsTeacher()]
        return [permissions.IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)


class QuestionViewSet(viewsets.ModelViewSet):
    serializer_class = QuestionSerializer
    permission_classes = [IsTeacher]

    def get_queryset(self):
        return Question.objects.filter(quiz_id=self.request.query_params.get('quiz'))


class TakeQuizView(APIView):
    """Student submits quiz answers -> auto-graded."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            quiz = Quiz.objects.prefetch_related('questions').get(pk=pk)
        except Quiz.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=404)
        if QuizAttempt.objects.filter(quiz=quiz, student=request.user).exists():
            return Response({'detail': 'You already attempted this quiz.'}, status=400)
        answers = request.data.get('answers', {})
        score = Decimal('0')
        for q in quiz.questions.all():
            if str(q.id) in answers and answers[str(q.id)] == q.answer:
                score += q.marks
        attempt = QuizAttempt.objects.create(quiz=quiz, student=request.user,
                                             answers=answers, score=score)
        return Response({'detail': 'Quiz graded.', 'score': str(attempt.score),
                         'total': str(quiz.total_marks)})
