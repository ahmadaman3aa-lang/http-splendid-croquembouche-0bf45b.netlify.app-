from django.contrib import admin
from .models import Assignment, Submission, Mark, Quiz, Question, QuizAttempt

admin.site.register(Assignment)
admin.site.register(Submission)
admin.site.register(Mark)
admin.site.register(Quiz)
admin.site.register(Question)
admin.site.register(QuizAttempt)
