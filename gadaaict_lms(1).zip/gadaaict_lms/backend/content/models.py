from django.db import models
from django.conf import settings


class Material(models.Model):
    """Teacher-uploaded resource: pdf, video, audio, ppt, link, note."""
    class Type(models.TextChoices):
        PDF = 'pdf', 'PDF Book'
        VIDEO = 'video', 'Video'
        AUDIO = 'audio', 'Audio'
        PPT = 'ppt', 'PowerPoint'
        LINK = 'link', 'External Link'
        NOTE = 'note', 'Lecture Note'

    subject = models.ForeignKey('academics.Subject', on_delete=models.CASCADE,
                                related_name='materials')
    teacher = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='materials')
    title = models.CharField(max_length=200)
    type = models.CharField(max_length=6, choices=Type.choices)
    file = models.FileField(upload_to='materials/', blank=True, null=True)
    link_url = models.URLField(blank=True)          # youtube / drive etc.
    language = models.CharField(max_length=2, default='en',
                                choices=[('en', 'EN'), ('am', 'AM'), ('om', 'OM')])
    is_pinned = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-is_pinned', '-created_at']

    def __str__(self):
        return self.title


class LiveClass(models.Model):
    class Status(models.TextChoices):
        SCHEDULED = 'scheduled', 'Scheduled'
        LIVE = 'live', 'Live Now'
        DONE = 'done', 'Finished'
        CANCELLED = 'cancelled', 'Cancelled'

    subject = models.ForeignKey('academics.Subject', on_delete=models.CASCADE,
                                related_name='live_classes')
    teacher = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='live_classes')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    meeting_url = models.URLField()                  # Jitsi / Zoom / Meet
    scheduled_at = models.DateTimeField()
    duration_min = models.PositiveSmallIntegerField(default=60)
    status = models.CharField(max_length=10, choices=Status.choices,
                              default=Status.SCHEDULED)

    class Meta:
        ordering = ['scheduled_at']

    def __str__(self):
        return f'{self.title} ({self.scheduled_at:%Y-%m-%d %H:%M})'


class ClassSession(models.Model):
    """A class that actually happened (for attendance records)."""
    live_class = models.ForeignKey(LiveClass, null=True, blank=True,
                                   on_delete=models.SET_NULL)
    subject = models.ForeignKey('academics.Subject', on_delete=models.CASCADE)
    teacher = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    topic = models.CharField(max_length=200, blank=True)
    held_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.subject} - {self.held_at:%Y-%m-%d}'


class Attendance(models.Model):
    class Status(models.TextChoices):
        PRESENT = 'present', 'Present'
        ABSENT = 'absent', 'Absent'
        LATE = 'late', 'Late'
        EXCUSED = 'excused', 'Excused'

    session = models.ForeignKey(ClassSession, on_delete=models.CASCADE,
                                related_name='attendance')
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    status = models.CharField(max_length=8, choices=Status.choices)

    class Meta:
        unique_together = ('session', 'student')
