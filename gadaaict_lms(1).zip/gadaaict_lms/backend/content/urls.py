from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MaterialViewSet, LiveClassViewSet, ClassSessionViewSet, AttendanceViewSet

router = DefaultRouter()
router.register('materials', MaterialViewSet)
router.register('live-classes', LiveClassViewSet)
router.register('sessions', ClassSessionViewSet)
router.register('attendance', AttendanceViewSet)
urlpatterns = [path('', include(router.urls))]
