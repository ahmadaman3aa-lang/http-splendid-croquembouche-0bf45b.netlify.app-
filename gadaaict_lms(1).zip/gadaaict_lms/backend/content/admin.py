from django.contrib import admin
from .models import Material, LiveClass, ClassSession, Attendance

admin.site.register(Material)
admin.site.register(LiveClass)
admin.site.register(ClassSession)
admin.site.register(Attendance)
