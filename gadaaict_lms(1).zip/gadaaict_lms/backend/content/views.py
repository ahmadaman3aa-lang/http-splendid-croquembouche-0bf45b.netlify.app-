from rest_framework import viewsets, permissions
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from .models import Material, LiveClass, ClassSession, Attendance
from .serializers import (MaterialSerializer, LiveClassSerializer,
                          ClassSessionSerializer, AttendanceSerializer)
from accounts.permissions import IsTeacher, IsAdmin


class MaterialViewSet(viewsets.ModelViewSet):
    serializer_class = MaterialSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['subject', 'type', 'language']

    def get_queryset(self):
        # Students only see materials for subjects of their own grade
        u = self.request.user
        qs = Material.objects.select_related('subject__grade', 'teacher')
        if u.role == 'student':
            return qs.filter(subject__grade=u.grade)
        return qs

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsTeacher()]
        return [permissions.IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)


class LiveClassViewSet(viewsets.ModelViewSet):
    serializer_class = LiveClassSerializer
    filterset_fields = ['subject', 'status']

    def get_queryset(self):
        u = self.request.user
        qs = LiveClass.objects.select_related('subject', 'teacher')
        if u.role == 'student':
            return qs.filter(subject__grade=u.grade)
        return qs

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsTeacher()]
        return [permissions.IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)


class ClassSessionViewSet(viewsets.ModelViewSet):
    serializer_class = ClassSessionSerializer
    permission_classes = [IsTeacher]

    def get_queryset(self):
        return ClassSession.objects.select_related('subject', 'teacher')

    def perform_create(self, serializer):
        serializer.save(teacher=self.request.user)


class AttendanceViewSet(viewsets.ModelViewSet):
    """Teacher marks attendance; students can view their own records."""
    serializer_class = AttendanceSerializer

    def get_queryset(self):
        u = self.request.user
        qs = Attendance.objects.select_related('student')
        if u.role == 'student':
            return qs.filter(student=u)
        return qs

    def get_permissions(self):
        if self.request.user.role == 'student':
            return [permissions.IsAuthenticated()]
        return [IsTeacher()]

    def bulk_mark(self, request):      # POST /attendance/bulk/
        """[{student_id, status}, ...] for one session."""
        session_id = request.data.get('session_id')
        rows = request.data.get('rows', [])
        for row in rows:
            Attendance.objects.update_or_create(
                session_id=session_id, student_id=row['student_id'],
                defaults={'status': row['status']})
        return Response({'detail': f'{len(rows)} attendance records saved.'})
