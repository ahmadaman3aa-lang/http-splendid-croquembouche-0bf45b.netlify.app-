from rest_framework import serializers
from .models import Material, LiveClass, ClassSession, Attendance


class MaterialSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.first_name', read_only=True)
    file_url = serializers.SerializerMethodField()

    class Meta:
        model = Material
        fields = ['id', 'subject', 'teacher', 'teacher_name', 'title', 'type',
                  'file', 'file_url', 'link_url', 'language', 'is_pinned', 'created_at']
        read_only_fields = ['teacher']

    def get_file_url(self, obj):
        return obj.file.url if obj.file else None


class LiveClassSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.first_name', read_only=True)
    subject_name = serializers.CharField(source='subject.name_en', read_only=True)

    class Meta:
        model = LiveClass
        fields = ['id', 'subject', 'subject_name', 'teacher', 'teacher_name', 'title',
                  'description', 'meeting_url', 'scheduled_at', 'duration_min', 'status']
        read_only_fields = ['teacher']


class AttendanceSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.first_name', read_only=True)

    class Meta:
        model = Attendance
        fields = ['id', 'session', 'student', 'student_name', 'status']


class ClassSessionSerializer(serializers.ModelSerializer):
    attendance = AttendanceSerializer(many=True, read_only=True)

    class Meta:
        model = ClassSession
        fields = ['id', 'live_class', 'subject', 'teacher', 'topic', 'held_at', 'attendance']
